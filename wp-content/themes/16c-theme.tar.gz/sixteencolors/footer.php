    <footer class=container>
        <div class=grid_3>
            <p>(c) 2011 Sixteen Colors</p>
            <p class=designedby>Artwork by enzO [<a href="http://blocktronics.net/">b7</a>]</p>
        </div>
        <div class=grid_2>
        </div>
        <div class=grid_4 id=connect>
            <h2>Connect with 16c...</h2>
            <ul>
                <li><a href="http://twitter.com/sixteencolors">Twitter</a> <a href="http://facebook.com/sixteencolors">Facebook</a></li>
                <li>Email <a href="mailto:contact@sixteencolors.net">contact@sixteencolors.net</a></li>
                <li>Feeds <a href="http://feeds.feedburner.com/SixteenColorsAnsiAndAsciiArchive-News">Sixteen Colors News</a><!-- <a href="#">Latest Artpacks</a> --></li>
            </ul>
        </div>
    </footer>
</body>
</html>
